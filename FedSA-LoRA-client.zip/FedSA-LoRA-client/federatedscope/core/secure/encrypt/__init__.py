from federatedscope.core.secure.encrypt.dummy_encrypt import \
    DummyEncryptKeypair

__all__ = ['DummyEncryptKeypair']
