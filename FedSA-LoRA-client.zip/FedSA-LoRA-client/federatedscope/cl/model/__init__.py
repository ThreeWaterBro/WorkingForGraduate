from __future__ import absolute_import
from __future__ import print_function
from __future__ import division

from federatedscope.cl.model.SimCLR import get_simclr

__all__ = ['get_simclr']
