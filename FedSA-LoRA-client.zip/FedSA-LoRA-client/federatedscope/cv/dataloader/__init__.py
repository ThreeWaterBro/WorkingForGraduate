from federatedscope.cv.dataloader.dataloader import load_cv_dataset

__all__ = ['load_cv_dataset']
