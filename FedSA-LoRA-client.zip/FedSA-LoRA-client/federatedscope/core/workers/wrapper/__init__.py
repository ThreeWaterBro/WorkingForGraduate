from federatedscope.core.workers.wrapper.fedswa import wrap_swa_server

__all__ = ['wrap_swa_server']
