from federatedscope.core.regularizer.proximal_regularizer import *
