from federatedscope.cl.dataloader.Cifar10 import load_cifar_dataset

__all__ = ['load_cifar_dataset']
